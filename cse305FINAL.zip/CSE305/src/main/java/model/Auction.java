package model;

public class Auction {

	/*
	 * This class is a representation of the auction table in the database
	 * Each instance variable has a corresponding getter and setter
	 */

	private int auctionID;
	private float bidIncrement;
	private float openingBid;
	private float closingBid;
	private float proxyBid;
	private float currentBid;
	private float reserve;
	private int monitor;
	private int itemID;
	
	public int getAuctionID() {
		return auctionID;
	}
	public void setAuctionID(int auctionID) {
		this.auctionID = auctionID;
	}
	public float getBidIncrement() {
		return bidIncrement;
	}
	public void setBidIncrement(float bidIncrement) {
		this.bidIncrement = bidIncrement;
	}
	public float getOpeningBid() {
		return openingBid;
	}
	public void setOpeningBid(float openingBid) {
		this.openingBid = openingBid;
	}
	public float getClosingBid() {
		return closingBid;
	}
	public void setClosingBid(float closingBid) {
		this.closingBid = closingBid;
	}
	public float getProxyBid() {
		return proxyBid;
	}
	public void setProxyBid(float proxyBid) {
		this.proxyBid = proxyBid;
	}
	public float getCurrentBid() {
		return currentBid;
	}
	public void setCurrentBid(float currentBid) {
		this.currentBid = currentBid;
	}
	public float getReserve() {
		return reserve;
	}
	public void setReserve(float reserve) {
		this.reserve = reserve;
	}
	public int getMonitor() {
		return monitor;
	}
	public void setMonitor(int monitor) {
		this.monitor = monitor;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	
	
}