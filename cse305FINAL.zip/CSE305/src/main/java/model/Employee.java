package model;

public class Employee {
	
	/*
	 * This class is a representation of the employee table in the database
	 * Each instance variable has a corresponding getter and setter
	 */

	private int employeeID;
	private String startDate;
	private float hourlyRate;
	private String title;
	
	public int getEmployeeID() {
		return this.employeeID;
	}
	public String getStartDate() {
		return this.startDate;
	}
	public float getHourlyRate() {
		return this.hourlyRate;
	}
	public String getTitle() {
		return this.title;
	}
	public void setEmployeeID(int EmployeeId) {
		this.employeeID = EmployeeId;
	}
	public void setStartDate(String StartDate) {
		this.startDate = StartDate;
	}
	public void setHourlyRate(float HourlyRate) {
		this.hourlyRate = HourlyRate;
	}
	public void setTitle(String Title) {
		this.title = Title;
	}
	

}