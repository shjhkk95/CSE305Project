package model;

public class Post {

	private String customerID;
	private int auctionID;
	private String postDate;
	private String closingDate;
	
	public String getCustomerID(){
		return this.customerID;
	}
	public int getAuctionID() {
		return this.auctionID;
	}
	public String getPostDate() {
		return this.postDate;
	}
	public String getClosingDate() {
		return this.closingDate;
	}
	public void setCustomerID(String CustomerID) {
		this.customerID = CustomerID;
	}
	public void setAuctionID(int AuctionID) {
		this.auctionID = AuctionID;
	}
	public void setPostDate(String PostDate) {
		this.postDate = PostDate;
	}
	public void setClosingDate(String ClosingDate) {
		this.closingDate = ClosingDate;
	}
	
	
	
}