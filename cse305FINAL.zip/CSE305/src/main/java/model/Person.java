package model;

public class Person {
	
	/*
	 * This class is a representation of the Person table in the database
	 * Each instance variable has a corresponding getter and setter
	 */
	
	private int SSN;
	private String firstName;
	private String lastName;
	private String Address;
	private String City;
	private String State;
	private int zipCode;
	private String telephone;
	private String email;
	private String PWD;

	
	public int getSSN() {
		return SSN;
	}


	public void setSSN(int SSN) {
		this.SSN = SSN;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String city) {
		City = city;
	}


	public String getState() {
		return State;
	}


	public void setState(String state) {
		State = state;
	}


	public int getZipCode() {
		return zipCode;
	}


	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}


	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPWD() {
		return PWD;
	}


	public void setPWD(String PWD) {
		this.PWD = PWD;
	}
	
	@Override
	public String toString() {
		return "The Person Details are: <br/>SSN=" + SSN + "<br/>First Name=" + firstName + "<br/>Last Name=" + lastName
				+ "<br/>Address=" + Address + "<br/>City=" + City + "<br/>State=" + State + "<br/>Zip Code=" + zipCode
				+ "<br/>Telephone=" + telephone + "<br/>Email=" + email + "<br/>PWD=" + PWD; 
	}
	
}
