package model;

public class Customer {
	
	/*
	 * This class is a representation of the customer table in the database
	 * Each instance variable has a corresponding getter and setter
	 */
	
	private int customerID;
	private String creditCardNum;
	private int rating;
	
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCreditCardNum() {
		return creditCardNum;
	}
	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", creditCardNum=" + creditCardNum + ", rating=" + rating + "]";
	}

	
}
