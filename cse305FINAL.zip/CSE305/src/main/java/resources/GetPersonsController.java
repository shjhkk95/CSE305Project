package resources;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PersonDao;
import model.Person;

/**
 * Servlet implementation class GetPersonController
 */
public class GetPersonsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetPersonsController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * This method receives the "Search Keyword" data from "Search Person" page
		 * This data is sent to the getPersons method in the dao.PersonDao class
		 * The data received from the getPersons method is sent to the Person Listing page as request attribute "Persons"
		 * This method redirects to the Person Listing page
		 */
		
		String searchKeyword = request.getParameter("searchKeyword");
		
		PersonDao dao = new PersonDao();
		List<Person> Persons = new ArrayList<Person>(); 
		Persons = dao.getAllPersons();
		
		request.setAttribute("Persons", Persons);
		RequestDispatcher rd = request.getRequestDispatcher("showPerson.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
