package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import model.Bid;
import model.Customer;

public class BidDao {

public List<Bid> getBidHistory(String auctionID) {
		
		List<Bid> bids = new ArrayList<Bid>();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" SELECT * FROM Bid B WHERE B.AuctionID = " + Integer.parseInt(auctionID));
	
		while (rs.next()) {
				Bid bid = new Bid();
				bid.setCustomerID(rs.getString("CustomerId"));
				bid.setAuctionID(rs.getInt("AuctionId"));
				bid.setBidTime(rs.getString("BidTime"));
				bid.setBidPlaced(rs.getFloat("BidPlaced"));
				bids.add(bid);
						
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
	
		return bids;
	}

	public List<Bid> getAuctionHistory(String customerID) {
		
		List<Bid> bids = new ArrayList<Bid>();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" Select * from BID B where B.CustomerID = " + Integer.parseInt(customerID));

			
		while (rs.next()) {
				Bid bid = new Bid();
				bid.setCustomerID(rs.getString("CustomerID"));
				bid.setAuctionID(rs.getInt("AuctionID"));
				bid.setBidTime(rs.getString("BidTime"));
				bid.setBidPlaced(rs.getFloat("BidPlaced"));

				bids.add(bid);								
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return bids;		

	}

	public Bid submitBid(String auctionID, String itemID, Float currentBid, Float maxBid, String customerID) {

		/*
		 * The students code to insert data in the database
		 * auctionID, which is the Auction's ID for which the bid is submitted, is given as method parameter
		 * itemID, which is the Item's ID for which the bid is submitted, is given as method parameter
		 * pBid, which is the Customer's current bid, is given as method parameter
		 * maxBid, which is the Customer's maximum bid for the item, is given as method parameter
		 * customerID, which is the Customer's ID, is given as method parameter
		 * Query to submit a bid by a customer, indicated by customerID, must be implemented
		 * After inserting the bid data, return the bid details encapsulated in "bid" object
		 */

		Bid bid = new Bid();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"INSERT INTO BID VALUES (?,?,CURRENT_TIMESTAMP(),?)");
			pstmt.setInt(1, Integer.parseInt(customerID));
			pstmt.setInt(2, Integer.parseInt(auctionID));
			pstmt.setFloat(3, currentBid);
			pstmt.executeUpdate();
			
			updateMaxBidAuction(auctionID, maxBid);
			bid = getBid(auctionID, customerID, currentBid);
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
		return bid;
	}

	private void updateMaxBidAuction(String auctionID, float proxyBid) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"UPDATE AUCTION SET PROXYBID = ? where auctionID = '" + auctionID + "'");
			pstmt.setFloat(1, proxyBid);
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public List<Bid> getSalesListing(String searchKeyword) {
		
		List<Bid> bids = new ArrayList<Bid>();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" Select B.CustomerID, B.AuctionID, B.BidTime, B.BidPlaced from Bid B, auction A, Item I, Customer C, Person P " +
					" where  B.auctionID = A.auctionID " + 
					" and A.ItemId = I.ItemID " + 
					" and B.CustomerID = C.CustomerID " + 
					" and C.CustomerID = P.SSN and " + 
					" (I.ItemName like '" + searchKeyword + "'" + 
					" or P.FirstName like '" + searchKeyword+ "' or P.LastName like '" + searchKeyword+ "')");

			
		while (rs.next()) {
				Bid bid = new Bid();
				bid.setCustomerID(rs.getString("CustomerID"));
				bid.setAuctionID(rs.getInt("AuctionID"));
				bid.setBidTime(rs.getString("BidTime"));
				bid.setBidPlaced(rs.getFloat("BidPlaced"));

				bids.add(bid);				
				
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return bids;
	}
	
	
	public Bid getBid(String auctionID, String customerID, float currentBid) {
		Bid bid = new Bid();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
				"SELECT * FROM BID WHERE AUCTIONID = '" + auctionID + "' and customerID = '" + customerID + "' and bidPlaced = '" + currentBid + "'");
		rs.next();
		bid.setAuctionID(rs.getInt("AuctionID"));
		bid.setCustomerID(rs.getString("CustomerID"));
		bid.setBidPlaced(rs.getFloat("bidPlaced"));
		bid.setBidTime(rs.getString("bidTime"));

	}
	catch(Exception e) {
		System.out.println(e);
		
	}
		return bid;
	}
}
