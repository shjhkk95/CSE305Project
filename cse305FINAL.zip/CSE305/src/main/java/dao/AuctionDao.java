package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Auction;
import model.Bid;
import model.Customer;
import model.Item;

public class AuctionDao {
	
public List<Auction> getAllAuctions() {
		
		List<Auction> auctions = new ArrayList<Auction>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from Auction");

			
		while (rs.next()) {
				Auction auction = new Auction();
				auction.setAuctionID(rs.getInt("AuctionID"));
				auction.setBidIncrement(rs.getFloat("BidIncrement"));
				auction.setOpeningBid(rs.getFloat("OpeningBid"));
				auction.setClosingBid(rs.getFloat("ClosingBid"));
				auction.setProxyBid(rs.getFloat("ProxyBid"));
				auction.setCurrentBid(rs.getFloat("CurrentBid"));
				auction.setReserve(rs.getFloat("Reserve"));
				auction.setMonitor(rs.getInt("Monitor"));
				auction.setItemID(rs.getInt("ItemID"));
				auctions.add(auction);
				
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return auctions;

	}

	public List<Auction> getAuctions(String customerID) {
		
		List<Auction> auctions = new ArrayList<Auction>();
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Each record is required to be encapsulated as a "Auction" class object and added to the "auctions" ArrayList
		 * Query to get data about all the auctions in which a customer participated should be implemented
		 * customerID is the customer's primary key, given as method parameter
		 */
		
		/*Sample data begins*/
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from Auction");
			
			while (rs.next()) {
				Auction auction = new Auction();
				auction.setAuctionID(rs.getInt("AuctionID"));
				auction.setBidIncrement(rs.getFloat("BidIncrement"));
				auction.setOpeningBid(rs.getFloat("OpeningBid"));
				auction.setClosingBid(rs.getFloat("ClosingBid"));
				auction.setProxyBid(rs.getFloat("ProxyBid"));
				auction.setCurrentBid(rs.getFloat("CurrentBid"));
				auction.setReserve(rs.getFloat("Reserve"));
				auction.setMonitor(rs.getInt("Monitor"));
				auction.setItemID(rs.getInt("ItemID"));
				auctions.add(auction);
			}
		}
	catch(Exception e) {
		System.out.println(e);
	}
	
		
		return auctions;

	}

	public List<Auction> getOpenAuctions(String employeeEmail) {
		List<Auction> auctions = new ArrayList<Auction>();
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Each record is required to be encapsulated as a "Auction" class object and added to the "auctions" ArrayList
		 * Query to get data about all the auctions in which a customer participated should be implemented
		 * customerID is the customer's primary key, given as method parameter
		 */
		
		/*Sample data begins*/
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from auction A, person P, Post O where P.SSN = A.monitor and O.auctionID = A.auctionID and P.email = '" + employeeEmail +"' and O.closingDate < CURRENT_TIMESTAMP");

			
			while (rs.next()) {
				Auction auction = new Auction();
				auction.setAuctionID(rs.getInt("AuctionID"));
				auction.setBidIncrement(rs.getFloat("BidIncrement"));
				auction.setOpeningBid(rs.getFloat("OpeningBid"));
				auction.setClosingBid(rs.getFloat("ClosingBid"));
				auction.setProxyBid(rs.getFloat("ProxyBid"));
				auction.setCurrentBid(rs.getFloat("CurrentBid"));
				auction.setReserve(rs.getFloat("Reserve"));
				auction.setMonitor(rs.getInt("Monitor"));
				auction.setItemID(rs.getInt("ItemID"));
				auctions.add(auction);
			}
		}
	catch(Exception e) {
		System.out.println(e);
	}

		return auctions;

		
	}

	public String recordSale(String auctionID) {
		CustomerDao.insertFinalBid(auctionID);
		CustomerDao.changeClosingBid(auctionID);
		CustomerDao.changeClosingTime(auctionID);
		
		return "success";
	}
	
	public static Auction getAuctionInfo(String auctionID) {
		Auction auction = new Auction();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" select * from auction where auctionID = " + auctionID);		

			rs.next();
				auction.setAuctionID(rs.getInt("AuctionID"));
				auction.setBidIncrement(rs.getFloat("BidIncrement"));
				auction.setOpeningBid(rs.getFloat("OpeningBid"));
				auction.setClosingBid(rs.getFloat("ClosingBid"));
				auction.setProxyBid(rs.getFloat("ProxyBid"));
				auction.setCurrentBid(rs.getFloat("CurrentBid"));
				auction.setReserve(rs.getFloat("Reserve"));
				auction.setMonitor(rs.getInt("Monitor"));
				auction.setItemID(rs.getInt("ItemID"));

		}

		catch(Exception e) {
			System.out.println(e);
		}
		return auction;
	}
	
	public static Item getItemInfo(String itemID) {
		Item item = new Item();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from Item where ItemID = " + itemID);

		rs.next();
				item.setDescription(rs.getString("Description"));
				item.setItemName(rs.getString("ItemName"));
				item.setItemType(rs.getString("ItemType"));
				item.setYearManufactured(rs.getInt("YearManufactured"));
				item.setNumCopies(rs.getInt("NumCopies"));
				item.setItemID(rs.getInt("ItemID"));
		}

		catch(Exception e) {

			System.out.println(e);

		}
		return item;
	}
	
	public static Bid getBidInfo(String auctionID) {
		Bid bid = new Bid();
		try {

			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");

			Statement st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from Bid B where B.auctionID = " + auctionID  

					+ " and B.bidPlaced >= all(SELECT B1.bidPlaced "

					+ "from Bid B1, Auction A1 "

					+ "where B.AuctionID = B1.AuctionID and B1.AuctionID = A1.AuctionID and A1.AuctionID = " + auctionID + ")");

			

			rs.next();

			bid.setAuctionID(rs.getInt("AuctionID"));

			bid.setBidPlaced(rs.getFloat("BidPlaced"));

			bid.setBidTime(rs.getString("bidTime"));

			bid.setCustomerID(rs.getString("customerID"));

		}

		catch(Exception e) {

			System.out.println(e);

		}
		return bid;
	}

	public static Customer getCustomerInfo(String auctionID) {
		Customer customer = new Customer();
		try {

			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");

			Statement st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from Bid B, Customer C where B.CustomerID = C.CustomerID and B.auctionID = " + auctionID  

					+ " and B.bidPlaced >= all(SELECT B1.bidPlaced "

					+ "from Bid B1, Auction A1 "

					+ "where B.AuctionID = B1.AuctionID and B1.AuctionID = A1.AuctionID and A1.AuctionID = " + auctionID + ")");

			

			rs.next();

			customer.setCreditCardNum(rs.getString("CreditCardNum"));

			customer.setCustomerID(rs.getInt("CustomerID"));

			customer.setRating(rs.getInt("rating"));

			

		}

		catch(Exception e) {

			System.out.println(e);

		}
		return customer;
	}

	public List getAuctionData(String auctionID, String itemID) {
		
		List output = new ArrayList();
		Item item = getItemInfo(auctionID);
		Bid bid = getBidInfo(auctionID);
		Auction auction = getAuctionInfo(auctionID);
		Customer customer = getCustomerInfo(auctionID);
		
		/*
		 * The students code to fetch data from the database will be written here
		 * The item details are required to be encapsulated as a "Item" class object
		 * The bid details are required to be encapsulated as a "Bid" class object
		 * The auction details are required to be encapsulated as a "Auction" class object
		 * The customer details are required to be encapsulated as a "Customer" class object
		 * Query to get data about auction indicated by auctionID and itemID should be implemented
		 * auctionID is the Auction's ID, given as method parameter
		 * itemID is the Item's ID, given as method parameter
		 * The customer details must include details about the current winner of the auction
		 * The bid details must include details about the current highest bid
		 * The item details must include details about the item, indicated by itemID
		 * The auction details must include details about the item, indicated by auctionID
		 * All the objects must be added in the "output" list and returned
		 */


		output.add(item);
		output.add(bid);
		output.add(auction);
		output.add(customer);
		
		
		
		return output;

	}

	
}
