package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Person;

import java.util.stream.IntStream;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

public class PersonDao {
	/*
	 * This class handles all the database operations related to the Person table
	 */
	
	/**
	 * @param String searchKeyword
	 * @return ArrayList<Person> object
	 */
	public Person getPerson(String searchKeyword) {
		/*
		 * This method fetches one or more persons based on the searchKeyword and returns it as an ArrayList
		 */
		Person person = new Person();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from person where SSN = " + searchKeyword );

			while (rs.next()) {
				person.setSSN(rs.getInt("SSN"));
				person.setFirstName(rs.getString("FirstName"));
				person.setLastName(rs.getString("LastName"));
				person.setCity(rs.getString("City"));
				person.setEmail(rs.getString("Email"));
				person.setPWD(rs.getString("PWD"));
				person.setTelephone(rs.getString("Telephone"));
				person.setState(rs.getString("State"));
				person.setZipCode(rs.getInt("ZipCode"));
				person.setAddress(rs.getString("Address"));
					
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return person;
	}
	
	public List<Person> getAllPersons() {
		/*
		 * This method fetches one or more persons based on the searchKeyword and returns it as an ArrayList
		 */
		
		List<Person> persons = new ArrayList<Person>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from person");

			while (rs.next()) {
				Person person = new Person();
				person.setSSN(rs.getInt("SSN"));
				person.setFirstName(rs.getString("FirstName"));
				person.setLastName(rs.getString("LastName"));
				person.setCity(rs.getString("City"));
				person.setEmail(rs.getString("Email"));
				person.setPWD(rs.getString("PWD"));
				person.setTelephone(rs.getString("Telephone"));
				person.setState(rs.getString("State"));
				person.setZipCode(rs.getInt("ZipCode"));
				person.setAddress(rs.getString("Address"));
				persons.add(person);	
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return persons;
	}
	
	public String addPerson(Person person) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"INSERT INTO PERSON VALUES (?,?,?,?,?,?,?,?,?,?)");
			int count = 1;
			pstmt.setInt(1, person.getSSN());
			System.out.println(count++);

			System.out.println(count++);
			pstmt.setString(2, person.getLastName());
			System.out.println(count++);
			pstmt.setString(3, person.getFirstName());
			System.out.println(count++);
			pstmt.setString(4, person.getAddress());
			System.out.println(count++);
			pstmt.setString(5, person.getCity());
			System.out.println(count++);

			pstmt.setString(6, person.getState());
			System.out.println(count++);

			pstmt.setInt(7, person.getZipCode());
			System.out.println(count++);

			pstmt.setString(8, person.getTelephone());
			System.out.println(count++);

			pstmt.setString(9, person.getEmail());
			System.out.println(count++);

			pstmt.setString(10, person.getPWD());
			System.out.println(count++);

			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	public String editPerson(Person person) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"UPDATE PERSON SET SSN = ?, LastName = ?, FirstName = ?, Address = ?, City = ?, State = ?, ZipCode = ?"
					+ " , Telephone = ?, Email = ?, PWD = ? WHERE SSN = ?");
			int count = 1;
			pstmt.setInt(1, person.getSSN());
			System.out.println(count++);
			pstmt.setString(2, person.getLastName());
			System.out.println(count++);
			pstmt.setString(3, person.getFirstName());
			System.out.println(count++);
			pstmt.setString(4, person.getAddress());
			System.out.println(count++);
			pstmt.setString(5, person.getCity());
			System.out.println(count++);

			pstmt.setString(6, person.getState());
			System.out.println(count++);

			pstmt.setInt(7, person.getZipCode());
			System.out.println(count++);

			pstmt.setString(8, person.getTelephone());
			System.out.println(count++);

			pstmt.setString(9, person.getEmail());
			System.out.println(count++);

			pstmt.setString(10, person.getPWD());
			System.out.println(count++);

			pstmt.setInt(11, person.getSSN());
			System.out.println(count++);
			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}
	
	public String deletePerson(String SSN) {

		/*
		 * This method deletes a customer returns "success" string on success, else returns "failure"
		 * The students code to delete the data from the database will be written here
		 * customerID, which is the Customer's ID who's details have to be deleted, is given as method parameter
		 */

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate("DELETE FROM PERSON WHERE SSN = " + SSN );
				
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
		
	}


}