package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Auction;
import model.Customer;
import model.Person;


public class CustomerDao {
	
	private final static String soldQuery = " CREATE VIEW Sold (CustomerID, AuctionID, SoldPrice) AS " +
			" SELECT B1.CustomerID, B1.AuctionID, B1.BidPlaced AS SoldPrice FROM Bid B1 " +
			" WHERE B1.BidTime > CURRENT_TIMESTAMP AND "+
			" B1.BidPlaced >= ALL (SELECT B2.BidPlaced FROM Bid B2 WHERE B1.AuctionID = B2.AuctionID) ";
	private final static String customerRevenueQuery = " CREATE VIEW CustomerRevenue (CustomerID, Revenue) AS " +
			" SELECT P.CustomerID, SUM(S.SoldPrice) "+
			" FROM Sold S, Post P, Auction A "+
			" WHERE P.AuctionID = A.AuctionID AND A.AuctionID = S.AuctionID "+
			" GROUP BY P.CustomerID ";
	private final static String boughtQuery = " CREATE VIEW Bought(CustomerID, ItemID, Type) AS " +
			" SELECT B1.CustomerID, I.ItemID, I.ItemType AS Type " +
			" FROM Bid B1, Item I, Auction A " +
			" WHERE B1.AuctionID = A.AuctionID AND A.ItemID = I.ItemID AND B1.BidTime > CURRENT_TIMESTAMP AND " +
			" B1.BidPlaced >= ALL (SELECT B2.BidPlaced FROM Bid B2 WHERE B1.AuctionID = B2.AuctionID) ";
	private final static String CRRQuery = " CREATE VIEW CustomerRepRevenue(EmployeeID, Revenue) As "
			+ "SELECT A.Monitor, SUM(S.SoldPRice) From Sold S, Auction A "
			+ "WHERE S.AuctionId = A.AuctionId "
			+ "Group By A.Monitor";
	/*
	 * This class handles all the database operations related to the customer table
	 */
	
	/**
	 * @param String searchKeyword
	 * @return ArrayList<Customer> object
	 */
	public List<Customer> getAllCustomers() {
		/*
		 * This method fetches one or more customers based on the searchKeyword and returns it as an ArrayList
		 */
		
		List<Customer> customers = new ArrayList<Customer>();

		/*
		 * The students code to fetch data from the database based on searchKeyword will be written here
		 * Each record is required to be encapsulated as a "Customer" class object and added to the "customers" List
		 */
		
		/*Sample data begins*/
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from Customer");

			
		while (rs.next()) {
				Customer cus = new Customer();
				cus.setCustomerID(rs.getInt("CustomerID"));
				cus.setCreditCardNum(rs.getString("CreditCardNum"));
				cus.setRating(rs.getInt("Rating"));
				
				customers.add(cus);
				
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return customers;
	}


	public Customer getHighestRevenueCustomer() {
		/*
		 * This method fetches the customer who generated the highest total revenue and returns it
		 * The students code to fetch data from the database will be written here
		 * The customer record is required to be encapsulated as a "Customer" class object
		 */
		Customer cus = new Customer();
		executeSoldQuery();
		executeCustomerRevenueQuery();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
			" SELECT CR.CustomerID FROM CustomerRevenue CR WHERE CR.Revenue >= ALL (SELECT CR1.Revenue FROM CustomerRevenue CR1) ");

			while (rs.next()) {
				cus = getCustomer(rs.getString("CustomerID"));
				return cus;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return cus;

		
	}

	public static  void executeBoughtQuery() {
		dropView("bought");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(boughtQuery);
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}


	public static void executeCustomerRevenueQuery() {
		dropView("customerrevenue");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(customerRevenueQuery);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}


	public static void executeSoldQuery() {
		dropView("sold");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(soldQuery);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void changeClosingBid(String auctionID) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(" update auction set closingbid = currentbid where "
					+ " auctionID = " + Integer.parseInt(auctionID));

		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	public static void changeClosingTime(String auctionID) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(" update post set closingTime = CURRENT_TIMESTAMP where "
					+ " auctionID = " + Integer.parseInt(auctionID));

		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	public static void dropView(String viewName) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate("DROP VIEW IF EXISTS " + viewName);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}


	public List<Person> getCustomerMailingList() {

		
		List<Person> persons = new ArrayList<Person>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT P.SSN, P.LastName, P.FirstName, P.Address, P.Email\r\n" + 
					"		FROM Customer C, Person P\r\n" + 
					"		WHERE C.CustomerID = P.SSN");

			while (rs.next()) {
				Person person = new Person();
				person.setSSN(rs.getInt("SSN"));
				person.setFirstName(rs.getString("FirstName"));
				person.setLastName(rs.getString("LastName"));
				person.setEmail(rs.getString("Email"));
				person.setAddress(rs.getString("Address"));
				persons.add(person);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return persons;
	}

	public Customer getCustomer(String customerID) {

		Customer cus = new Customer();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM CUSTOMER C WHERE C.CustomerID = '" + customerID + "'");

			while (rs.next()) {
			cus.setCustomerID(Integer.parseInt(customerID));
			cus.setCreditCardNum(rs.getString("CreditCardNum"));
			cus.setRating(rs.getInt("Rating"));
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return cus;
		
	}
	
	public String deleteCustomer(String customerID) {


		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate("DELETE FROM CUSTOMER  WHERE CustomerID = " + customerID);
				
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
		
	}


	public String getCustomerID(String username) {

		String result = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" SELECT C.CustomerID FROM CUSTOMER C, PERSON P "
					+ " WHERE C.CustomerID = P.SSN AND P.Email = " + username );
				
			while (rs.next()) {
				result = Integer.toString(rs.getInt("CustomerID"));
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return result;
	}


	public List<Customer> getSellers() {
		

		List<Customer> customers = new ArrayList<Customer>();
		
		try {
			executeSoldQuery();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" SELECT DISTINCT S.CustomerID FROM Sold S, Item I, Post P, Auction A "
					+ " WHERE P.AuctionID = A.AuctionID AND A.ItemID = I.ItemID AND A.AuctionID = S.AuctionID " );
				
			while (rs.next()) {
				Customer cus = new Customer();
				cus = getCustomer(rs.getString("CustomerID"));
				customers.add(cus);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		

		
		return customers;

	}


	public String addCustomer(Customer customer) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"INSERT INTO CUSTOMER VALUES (?,?,?)");
			pstmt.setInt(1, customer.getCustomerID());
			pstmt.setString(2, customer.getCreditCardNum());
			pstmt.setInt(3, customer.getRating());
			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	public String editCustomer(Customer customer) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"UPDATE CUSTOMER SET CustomerID = ?, CreditCardNum = ?, "
					+ "Rating = ? where CustomerID = ?");
			pstmt.setInt(1, customer.getCustomerID());
			pstmt.setString(2, customer.getCreditCardNum());
			pstmt.setInt(3, customer.getRating());
			pstmt.setInt(4, customer.getCustomerID());
			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}


	public static void executeCRRQuery() {
		dropView("CustomerRepRevenue");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate(CRRQuery);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}


	public static void insertFinalBid(String auctionID) {
		Auction auction = AuctionDao.getAuctionInfo(auctionID);
		Customer customer = AuctionDao.getCustomerInfo(auctionID);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"INSERT INTO BID VALUES (?,?,CURRENT_TIMESTAMP(),?)");
			pstmt.setInt(1, customer.getCustomerID());
			pstmt.setInt(2, auction.getAuctionID());
			pstmt.setFloat(3, auction.getProxyBid());
			pstmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}
