package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Employee;


public class EmployeeDao {
	/*
	 * This class handles all the database operations related to the employee table
	 */
	
	public String addEmployee(Employee employee) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"INSERT INTO EMPLOYEE VALUES (?,?,?,?)");
			pstmt.setInt(1, employee.getEmployeeID());
			pstmt.setString(2, employee.getStartDate());
			pstmt.setFloat(3, employee.getHourlyRate());
			pstmt.setString(4, employee.getTitle());
			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	public String editEmployee(Employee employee) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			PreparedStatement pstmt = con.prepareStatement(
					"UPDATE Employee SET EmployeeID = ?, StartDate = ?, "
					+ "HourlyRate = ?, Title = ? where EmployeeID = ?");
			pstmt.setInt(1, employee.getEmployeeID());
			pstmt.setString(2, employee.getStartDate());
			pstmt.setFloat(3, employee.getHourlyRate());
			pstmt.setString(4, employee.getTitle());
			pstmt.setInt(5, employee.getEmployeeID());
			pstmt.executeUpdate();
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	public String deleteEmployee(String employeeID) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			st.executeUpdate("DELETE FROM EMPLOYEE WHERE EmployeeID = '" + employeeID + "'");
				
			return "success";
		}
		catch(Exception e) {
			System.out.println(e);
			return "error";
		}
		
	}

	
	public List<Employee> getEmployees() {

		/*
		 * The students code to fetch data from the database will be written here
		 * Query to return details about all the employees must be implemented
		 * Each record is required to be encapsulated as a "Employee" class object and added to the "employees" List
		 */

		List<Employee> employees = new ArrayList<Employee>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" select * from employee ");
	
		while (rs.next()) {
				Employee employee = new Employee();
				employee.setEmployeeID(rs.getInt("EmployeeID"));
				employee.setStartDate(rs.getString("StartDate"));
				employee.setHourlyRate(rs.getFloat("HourlyRate"));
				employee.setTitle(rs.getString("Title"));
				
				employees.add(employee);										
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return employees;
	}

	public Employee getEmployee(String employeeID) {

		
		Employee employee = new Employee();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" select * from employee where employeeID =  '" + employeeID + "'");

			rs.next();
			
			employee.setEmployeeID(rs.getInt("EmployeeID"));
			employee.setStartDate(rs.getString("StartDate"));
			employee.setHourlyRate(rs.getFloat("HourlyRate"));
			employee.setTitle(rs.getString("Title"));
			
				
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return employee;
		
	}
	
	public Employee getHighestRevenueEmployee() {
		
		/*
		 * The students code to fetch employee data who generated the highest revenue will be written here
		 * The record is required to be encapsulated as a "Employee" class object
		 */
		
		CustomerDao.executeSoldQuery();
		CustomerDao.executeCRRQuery();
		
		Employee employee = new Employee();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" select * from CustomerRepRevenue CRR, Employee E where CRR.employeeID = E.EmployeeID and CRR.revenue >= All(Select CRR1.Revenue from CustomerRepRevenue CRR1)");

			
			while(rs.next()) {
			
			employee.setEmployeeID(rs.getInt("EmployeeID"));
			employee.setStartDate(rs.getString("StartDate"));
			employee.setHourlyRate(rs.getFloat("HourlyRate"));
			employee.setTitle(rs.getString("title"));
			
			}
	
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return employee;
	}

	public int getEmployeeID(String username) {
		Employee employee = new Employee();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final", "root", "as1anboy");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(" Select * from employee E, person P where P.SSN = E.employeeID and P.email = " + username);

			
			rs.next();
			
			employee.setEmployeeID(rs.getInt("EmployeeID"));
			employee.setStartDate(rs.getString("StartDate"));
			employee.setHourlyRate(rs.getFloat("HourlyRate"));

		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return employee.getEmployeeID();
	}

}
